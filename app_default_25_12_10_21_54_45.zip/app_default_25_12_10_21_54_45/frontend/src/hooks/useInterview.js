import { useContext } from 'react';
import { InterviewContext } from '../context/InterviewContext.js';

export const useInterview = () => {
  return useContext(InterviewContext);
};
