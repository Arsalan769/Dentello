import { useContext } from 'react';
import { ShortlistContext } from '../context/ShortlistContext.js';

export const useShortlist = () => {
  return useContext(ShortlistContext);
};
