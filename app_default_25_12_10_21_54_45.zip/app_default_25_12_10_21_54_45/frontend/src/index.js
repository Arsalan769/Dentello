import React from 'react';
import ReactDOM from 'react-dom/client';
import { BrowserRouter } from 'react-router-dom';
import App from './App.js';
import { AuthProvider } from './context/AuthContext.js';
import { ShortlistProvider } from './context/ShortlistContext.js';
import { InterviewProvider } from './context/InterviewContext.js';
import './styles/index.css';

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
    <AuthProvider>
      <ShortlistProvider>
        <InterviewProvider>
          <BrowserRouter>
            <App />
          </BrowserRouter>
        </InterviewProvider>
      </ShortlistProvider>
    </AuthProvider>
  </React.StrictMode>
);
