import React, { createContext, useState, useEffect, useCallback } from 'react';
import apiClient from '../api/apiClient.js';

export const AuthContext = createContext(null);

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  const login = async (username, password) => {
    try {
      const response = await apiClient.post('/auth/login', { username, password });
      const { token, user: userData } = response.data;
      localStorage.setItem('dentello_token', token);
      setUser(userData);
      return { success: true };
    } catch (error) {
      if (error.response && error.response.data.message) {
        return { success: false, message: error.response.data.message };
      }
      return { success: false, message: 'Login failed' };
    }
  };

  const logout = useCallback(() => {
    localStorage.removeItem('dentello_token');
    setUser(null);
  }, []);

  useEffect(() => {
    const checkUser = async () => {
      const token = localStorage.getItem('dentello_token');
      if (!token) {
        setUser(null);
        setLoading(false);
        return;
      }
      try {
        // Optionally fetch user profile here if backend supported it
        // For demo, decode token locally (not secure, but quick)
        const payloadBase64 = token.split('.')[1];
        if (!payloadBase64) throw new Error('Invalid token');
        const decoded = JSON.parse(atob(payloadBase64));
        setUser({ id: decoded.id, username: decoded.username, role: decoded.role });
      } catch {
        logout();
      }
      setLoading(false);
    };
    checkUser();
  }, [logout]);

  return (
    <AuthContext.Provider value={{ user, loading, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
};
