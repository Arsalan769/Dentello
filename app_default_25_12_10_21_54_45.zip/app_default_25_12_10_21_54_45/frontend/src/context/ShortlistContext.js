import React, { createContext, useState, useEffect, useContext } from 'react';
import apiClient from '../api/apiClient.js';
import { AuthContext } from './AuthContext.js';

export const ShortlistContext = createContext(null);

export const ShortlistProvider = ({ children }) => {
  const { user } = useContext(AuthContext);
  const [shortlist, setShortlist] = useState([]);
  const [loading, setLoading] = useState(false);

  const fetchShortlist = async () => {
    if (!user) {
      setShortlist([]);
      return;
    }
    setLoading(true);
    try {
      const response = await apiClient.get('/shortlist');
      setShortlist(response.data);
    } catch (error) {
      setShortlist([]);
    } finally {
      setLoading(false);
    }
  };

  const addDentist = async (dentistId) => {
    try {
      await apiClient.post('/shortlist', { dentistId });
      await fetchShortlist();
      return { success: true };
    } catch (error) {
      return { success: false, message: error.response?.data?.message || 'Failed to add' };
    }
  };

  const removeDentist = async (dentistId) => {
    try {
      await apiClient.delete('/shortlist', { data: { dentistId } });
      await fetchShortlist();
      return { success: true };
    } catch (error) {
      return { success: false, message: error.response?.data?.message || 'Failed to remove' };
    }
  };

  useEffect(() => {
    fetchShortlist();
  }, [user]);

  return (
    <ShortlistContext.Provider
      value={{ shortlist, loading, fetchShortlist, addDentist, removeDentist }}
    >
      {children}
    </ShortlistContext.Provider>
  );
};
