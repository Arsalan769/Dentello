import React, { createContext, useState, useEffect, useContext } from 'react';
import apiClient from '../api/apiClient.js';
import { AuthContext } from './AuthContext.js';

export const InterviewContext = createContext(null);

export const InterviewProvider = ({ children }) => {
  const { user } = useContext(AuthContext);
  const [interviews, setInterviews] = useState([]);
  const [loading, setLoading] = useState(false);

  const fetchInterviews = async () => {
    if (!user) {
      setInterviews([]);
      return;
    }
    setLoading(true);
    try {
      const response = await apiClient.get('/interviews');
      setInterviews(response.data);
    } catch (error) {
      setInterviews([]);
    } finally {
      setLoading(false);
    }
  };

  const createInterview = async (data) => {
    try {
      const response = await apiClient.post('/interviews', data);
      await fetchInterviews();
      return { success: true, interview: response.data };
    } catch (error) {
      return { success: false, message: error.response?.data?.message || 'Failed to schedule' };
    }
  };

  const updateOutcome = async (id, data) => {
    try {
      const response = await apiClient.patch(`/interviews/${id}/outcome`, data);
      await fetchInterviews();
      return { success: true, interview: response.data };
    } catch (error) {
      return { success: false, message: error.response?.data?.message || 'Failed to update outcome' };
    }
  };

  useEffect(() => {
    fetchInterviews();
  }, [user]);

  return (
    <InterviewContext.Provider value={{ interviews, loading, createInterview, updateOutcome }}>
      {children}
    </InterviewContext.Provider>
  );
};
