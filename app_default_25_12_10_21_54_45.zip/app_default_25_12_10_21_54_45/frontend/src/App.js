import React from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import LoginPage from './components/LoginPage.js';
import DentistDirectory from './components/DentistDirectory.js';
import ProtectedRoute from './components/ProtectedRoute.js';

function App() {
  return (
    <Routes>
      <Route path="/login" element={<LoginPage />} />
      <Route
        path="/dentists"
        element={
          <ProtectedRoute>
            <DentistDirectory />
          </ProtectedRoute>
        }
      />
      <Route path="*" element={<Navigate to="/dentists" replace />} />
    </Routes>
  );
}

export default App;
