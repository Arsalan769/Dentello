import React, { useState, useEffect } from 'react';
import { useInterview } from '../hooks/useInterview.js';

const InterviewOutcomeModal = ({ interview, onClose }) => {
  const { updateOutcome } = useInterview();
  const [notes, setNotes] = useState('');
  const [result, setResult] = useState('pending');
  const [status, setStatus] = useState('scheduled');
  const [error, setError] = useState('');
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    if (interview?.outcome) {
      setNotes(interview.outcome.notes || '');
      setResult(interview.outcome.result || 'pending');
    }
    if (interview?.status) {
      setStatus(interview.status);
    }
  }, [interview]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setSubmitting(true);
    const resultUpdate = await updateOutcome(interview._id, { notes, result, status });
    setSubmitting(false);
    if (resultUpdate.success) {
      onClose();
    } else {
      setError(resultUpdate.message || 'Failed to update outcome');
    }
  };

  if (!interview) return null;

  return (
    <>
      <div
        className="fixed inset-0 bg-black bg-opacity-50 z-50"
        onClick={onClose}
        aria-label="Close interview outcome modal"
      />
      <div
        className="fixed inset-0 flex items-center justify-center z-60 p-4"
        role="dialog"
        aria-modal="true"
        aria-labelledby="interview-outcome-title"
      >
        <form
          onSubmit={handleSubmit}
          className="bg-white rounded shadow-lg p-6 w-full max-w-md"
          onClick={(e) => e.stopPropagation()}
        >
          <h2 id="interview-outcome-title" className="text-xl font-semibold mb-4">
            Interview Outcome for {interview.dentist.name}
          </h2>
          {error && <p className="mb-4 text-red-600">{error}</p>}
          <label className="block mb-2 font-medium" htmlFor="status">
            Status
          </label>
          <select
            id="status"
            value={status}
            onChange={(e) => setStatus(e.target.value)}
            className="w-full border border-gray-300 rounded px-3 py-2 mb-4"
            required
          >
            <option value="scheduled">Scheduled</option>
            <option value="completed">Completed</option>
            <option value="canceled">Canceled</option>
          </select>
          <label className="block mb-2 font-medium" htmlFor="result">
            Result
          </label>
          <select
            id="result"
            value={result}
            onChange={(e) => setResult(e.target.value)}
            className="w-full border border-gray-300 rounded px-3 py-2 mb-4"
            required
          >
            <option value="pending">Pending</option>
            <option value="pass">Pass</option>
            <option value="fail">Fail</option>
          </select>
          <label className="block mb-2 font-medium" htmlFor="notes">
            Notes
          </label>
          <textarea
            id="notes"
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
            rows={4}
            className="w-full border border-gray-300 rounded px-3 py-2 mb-6 resize-none"
            placeholder="Add notes here..."
          />
          <div className="flex justify-end space-x-4">
            <button
              type="button"
              onClick={onClose}
              className="py-2 px-4 rounded border border-gray-400 hover:bg-gray-100 transition"
              disabled={submitting}
            >
              Cancel
            </button>
            <button
              type="submit"
              className="py-2 px-6 rounded bg-primary text-white hover:bg-blue-700 transition"
              disabled={submitting}
            >
              {submitting ? 'Saving...' : 'Save'}
            </button>
          </div>
        </form>
      </div>
    </>
  );
};

export default InterviewOutcomeModal;
