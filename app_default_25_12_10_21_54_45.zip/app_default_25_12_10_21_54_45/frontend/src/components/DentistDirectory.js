import React, { useEffect, useState } from 'react';
import apiClient from '../api/apiClient.js';
import DentistProfileDrawer from './DentistProfileDrawer.js';

const specialtiesDefault = [
  'Orthodontics',
  'Pediatrics',
  'General',
  'Endodontics',
  'Periodontics',
  'Prosthodontics',
  'Oral Surgery'
];

const DentistDirectory = () => {
  const [dentists, setDentists] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [filters, setFilters] = useState({
    specialty: '',
    location: '',
    availability: ''
  });
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [selectedDentistId, setSelectedDentistId] = useState(null);

  const fetchDentists = async () => {
    setLoading(true);
    setError('');
    try {
      const params = {
        page,
        limit: 10,
        ...filters
      };
      // Remove empty filters
      Object.keys(params).forEach((key) => {
        if (!params[key]) delete params[key];
      });
      const response = await apiClient.get('/dentists', { params });
      setDentists(response.data.dentists);
      setTotalPages(response.data.totalPages || 1);
    } catch (err) {
      setError('Failed to load dentists');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchDentists();
  }, [page, filters]);

  const handleFilterChange = (e) => {
    setPage(1);
    setFilters((prev) => ({
      ...prev,
      [e.target.name]: e.target.value
    }));
  };

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <h1 className="text-3xl font-bold mb-6 text-center">Dentist Directory</h1>
      <div className="max-w-5xl mx-auto">
        <form className="mb-6 grid grid-cols-1 sm:grid-cols-3 gap-4">
          <select
            name="specialty"
            value={filters.specialty}
            onChange={handleFilterChange}
            className="border border-gray-300 rounded px-3 py-2"
            aria-label="Filter by specialty"
          >
            <option value="">All Specialties</option>
            {specialtiesDefault.map((s) => (
              <option key={s} value={s}>
                {s}
              </option>
            ))}
          </select>
          <input
            name="location"
            type="text"
            placeholder="Location"
            value={filters.location}
            onChange={handleFilterChange}
            className="border border-gray-300 rounded px-3 py-2"
            aria-label="Filter by location"
          />
          <input
            name="availability"
            type="date"
            value={filters.availability}
            onChange={handleFilterChange}
            className="border border-gray-300 rounded px-3 py-2"
            aria-label="Filter by availability date"
          />
        </form>
        {loading && <p className="text-center text-gray-600">Loading dentists...</p>}
        {error && <p className="text-center text-red-600">{error}</p>}
        {!loading && dentists.length === 0 && (
          <p className="text-center text-gray-600">No dentists found</p>
        )}
        <ul className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {dentists.map((dentist) => (
            <li
              key={dentist._id}
              className="bg-white rounded shadow p-4 cursor-pointer hover:shadow-lg"
              tabIndex={0}
              onClick={() => setSelectedDentistId(dentist._id)}
              onKeyDown={(e) => {
                if (e.key === 'Enter' || e.key === ' ') {
                  setSelectedDentistId(dentist._id);
                }
              }}
              aria-label={`View details for ${dentist.name}`}
            >
              <h2 className="text-xl font-semibold">{dentist.name}</h2>
              <p className="text-sm text-gray-600">
                Specialty: {dentist.specialty} | Location: {dentist.location}
              </p>
              <p className="text-sm text-yellow-600">Rating: {dentist.ratings || 'N/A'}</p>
            </li>
          ))}
        </ul>
        <div className="flex justify-center mt-6 space-x-4">
          <button
            disabled={page <= 1}
            onClick={() => setPage((p) => Math.max(p - 1, 1))}
            className="px-4 py-2 bg-primary text-white rounded disabled:opacity-50"
          >
            Previous
          </button>
          <span className="self-center">
            Page {page} of {totalPages}
          </span>
          <button
            disabled={page >= totalPages}
            onClick={() => setPage((p) => Math.min(p + 1, totalPages))}
            className="px-4 py-2 bg-primary text-white rounded disabled:opacity-50"
          >
            Next
          </button>
        </div>
      </div>
      <DentistProfileDrawer
        dentistId={selectedDentistId}
        onClose={() => setSelectedDentistId(null)}
      />
    </div>
  );
};

export default DentistDirectory;
