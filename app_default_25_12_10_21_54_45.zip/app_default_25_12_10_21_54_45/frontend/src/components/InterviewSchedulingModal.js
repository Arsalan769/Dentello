import React, { useState } from 'react';
import { useInterview } from '../hooks/useInterview.js';

const interviewTypes = ['Zoom', 'In-person', 'Phone'];

const InterviewSchedulingModal = ({ dentist, onClose }) => {
  const { createInterview } = useInterview();
  const [scheduledAt, setScheduledAt] = useState('');
  const [time, setTime] = useState('');
  const [type, setType] = useState(interviewTypes[0]);
  const [error, setError] = useState('');
  const [submitting, setSubmitting] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    if (!scheduledAt || !time || !type) {
      setError('All fields are required');
      return;
    }
    const scheduledDateTime = new Date(`${scheduledAt}T${time}`);
    if (isNaN(scheduledDateTime.getTime())) {
      setError('Invalid date or time');
      return;
    }
    setSubmitting(true);
    const result = await createInterview({
      dentistId: dentist._id,
      scheduledAt: scheduledDateTime.toISOString(),
      type
    });
    setSubmitting(false);
    if (result.success) {
      onClose();
    } else {
      setError(result.message || 'Failed to schedule interview');
    }
  };

  return (
    <>
      <div
        className="fixed inset-0 bg-black bg-opacity-50 z-50"
        onClick={onClose}
        aria-label="Close interview scheduling modal"
      />
      <div
        className="fixed inset-0 flex items-center justify-center z-60 p-4"
        role="dialog"
        aria-modal="true"
        aria-labelledby="schedule-interview-title"
      >
        <form
          onSubmit={handleSubmit}
          className="bg-white rounded shadow-lg p-6 w-full max-w-md"
          onClick={(e) => e.stopPropagation()}
        >
          <h2 id="schedule-interview-title" className="text-xl font-semibold mb-4">
            Schedule Interview with {dentist.name}
          </h2>
          {error && <p className="mb-4 text-red-600">{error}</p>}
          <label className="block mb-2 font-medium" htmlFor="date">
            Date
          </label>
          <input
            id="date"
            type="date"
            value={scheduledAt}
            onChange={(e) => setScheduledAt(e.target.value)}
            className="w-full border border-gray-300 rounded px-3 py-2 mb-4"
            required
          />
          <label className="block mb-2 font-medium" htmlFor="time">
            Time
          </label>
          <input
            id="time"
            type="time"
            value={time}
            onChange={(e) => setTime(e.target.value)}
            className="w-full border border-gray-300 rounded px-3 py-2 mb-4"
            required
          />
          <label className="block mb-2 font-medium" htmlFor="type">
            Interview Type
          </label>
          <select
            id="type"
            value={type}
            onChange={(e) => setType(e.target.value)}
            className="w-full border border-gray-300 rounded px-3 py-2 mb-6"
            required
          >
            {interviewTypes.map((t) => (
              <option key={t} value={t}>
                {t}
              </option>
            ))}
          </select>
          <div className="flex justify-end space-x-4">
            <button
              type="button"
              onClick={onClose}
              className="py-2 px-4 rounded border border-gray-400 hover:bg-gray-100 transition"
              disabled={submitting}
            >
              Cancel
            </button>
            <button
              type="submit"
              className="py-2 px-6 rounded bg-primary text-white hover:bg-blue-700 transition"
              disabled={submitting}
            >
              {submitting ? 'Scheduling...' : 'Schedule'}
            </button>
          </div>
        </form>
      </div>
    </>
  );
};

export default InterviewSchedulingModal;
