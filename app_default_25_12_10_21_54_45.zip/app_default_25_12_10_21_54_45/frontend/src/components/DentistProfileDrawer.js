import React, { useState, useEffect } from 'react';
import apiClient from '../api/apiClient.js';
import InterviewSchedulingModal from './InterviewSchedulingModal.js';
import { useShortlist } from '../hooks/useShortlist.js';

const DentistProfileDrawer = ({ dentistId, onClose }) => {
  const [dentist, setDentist] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [isScheduling, setIsScheduling] = useState(false);
  const { shortlist, addDentist, removeDentist } = useShortlist();

  useEffect(() => {
    if (!dentistId) {
      setDentist(null);
      return;
    }
    const fetchDentist = async () => {
      setLoading(true);
      setError('');
      try {
        const response = await apiClient.get(`/dentists/${dentistId}`);
        setDentist(response.data);
      } catch {
        setError('Failed to load dentist details');
      } finally {
        setLoading(false);
      }
    };
    fetchDentist();
  }, [dentistId]);

  if (!dentistId) return null;

  const isShortlisted = shortlist.some((d) => d._id === dentistId);

  const handleShortlistToggle = async () => {
    if (isShortlisted) {
      const result = await removeDentist(dentistId);
      if (!result.success) alert(result.message);
    } else {
      const result = await addDentist(dentistId);
      if (!result.success) alert(result.message);
    }
  };

  return (
    <>
      <div
        className="fixed inset-0 bg-black bg-opacity-50 z-40"
        onClick={onClose}
        aria-label="Close dentist profile"
      />
      <aside
        className="fixed top-0 right-0 w-full max-w-md h-full bg-white shadow-lg z-50 overflow-y-auto"
        role="dialog"
        aria-modal="true"
        aria-labelledby="dentist-profile-title"
      >
        <div className="p-6 flex flex-col h-full">
          <button
            onClick={onClose}
            aria-label="Close"
            className="self-end text-gray-600 hover:text-gray-900 font-bold mb-4"
          >
            &times;
          </button>
          {loading && <p>Loading...</p>}
          {error && <p className="text-red-600">{error}</p>}
          {dentist && (
            <>
              <h2 id="dentist-profile-title" className="text-2xl font-bold mb-2">
                {dentist.name}
              </h2>
              <p className="text-sm text-gray-600 mb-1">
                Specialty: {dentist.specialty}
              </p>
              <p className="text-sm text-gray-600 mb-1">Location: {dentist.location}</p>
              <p className="text-sm text-yellow-600 mb-2">
                Rating: {dentist.ratings || 'N/A'}
              </p>
              <p className="mb-4 whitespace-pre-wrap">{dentist.bio || 'No bio available.'}</p>
              <div className="mb-4">
                <h3 className="font-semibold mb-1">Contact Info</h3>
                <p>Phone: {dentist.contact.phone}</p>
                <p>Email: {dentist.contact.email}</p>
              </div>
              <div className="mb-4">
                <h3 className="font-semibold mb-1">Availability</h3>
                {dentist.availability && dentist.availability.length > 0 ? (
                  <ul className="list-disc list-inside max-h-40 overflow-auto">
                    {dentist.availability.map((slot, idx) => (
                      <li key={idx}>
                        {new Date(slot.date).toLocaleDateString()} - {slot.startTime} to{' '}
                        {slot.endTime}
                      </li>
                    ))}
                  </ul>
                ) : (
                  <p>No availability information.</p>
                )}
              </div>
              <div className="flex space-x-4 mt-auto">
                <button
                  onClick={handleShortlistToggle}
                  className={`flex-1 py-2 rounded text-white ${
                    isShortlisted ? 'bg-red-600 hover:bg-red-700' : 'bg-primary hover:bg-blue-700'
                  } transition`}
                >
                  {isShortlisted ? 'Remove from Shortlist' : 'Add to Shortlist'}
                </button>
                <button
                  onClick={() => setIsScheduling(true)}
                  className="flex-1 py-2 rounded border border-primary text-primary hover:bg-primary hover:text-white transition"
                >
                  Schedule Interview
                </button>
              </div>
            </>
          )}
        </div>
      </aside>
      {isScheduling && (
        <InterviewSchedulingModal
          dentist={dentist}
          onClose={() => setIsScheduling(false)}
        />
      )}
    </>
  );
};

export default DentistProfileDrawer;
