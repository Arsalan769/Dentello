# Dentello - Dentist Directory and Interview Scheduling System

## Project Description

Dentello is a full-stack web application for managing a dentist directory, shortlisting preferred dentists, scheduling interviews, and recording interview outcomes. The system consists of a React frontend with Tailwind CSS and a Node.js backend with Express and MongoDB.

---

## Features

- **User Authentication**: Secure login with JWT tokens.
- **Dentist Directory**: Browse, filter, and paginate dentists by specialty, location, and availability.
- **Dentist Profiles**: Detailed profiles with contact info, bio, ratings, and availability.
- **Shortlist Management**: Add or remove dentists from your personal shortlist.
- **Interview Scheduling**: Schedule interviews with dentists specifying date, time, and type.
- **Interview Outcome Tracking**: Record notes and results for completed interviews.
- **Protected Routes**: Access control ensuring only authenticated users can access protected pages.

---

## Prerequisites

- **Node.js** (v18.x or higher recommended)
- **npm** (comes with Node.js)
- **MongoDB** (local or remote instance)

---

## Installation and Setup

### Backend Setup

1. Navigate to the backend directory:

    