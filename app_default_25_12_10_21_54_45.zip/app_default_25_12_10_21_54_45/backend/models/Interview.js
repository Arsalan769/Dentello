import mongoose from 'mongoose';

const interviewSchema = new mongoose.Schema(
  {
    user: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true
    },
    dentist: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Dentist',
      required: true
    },
    scheduledAt: {
      type: Date,
      required: true
    },
    type: {
      type: String,
      required: true,
      trim: true,
      maxlength: 50
    },
    outcome: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Outcome',
      default: null
    },
    status: {
      type: String,
      enum: ['scheduled', 'completed', 'canceled'],
      default: 'scheduled'
    }
  },
  {
    timestamps: true
  }
);

const Interview = mongoose.model('Interview', interviewSchema);

export default Interview;
