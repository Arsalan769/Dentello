import mongoose from 'mongoose';

const availabilitySlotSchema = new mongoose.Schema({
  date: {
    type: Date,
    required: true
  },
  startTime: {
    type: String,
    required: true,
    match: /^([0-1][0-9]|2[0-3]):([0-5][0-9])$/
  },
  endTime: {
    type: String,
    required: true,
    match: /^([0-1][0-9]|2[0-3]):([0-5][0-9])$/
  }
}, { _id: false });

const dentistSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: true,
      trim: true,
      maxlength: 100
    },
    specialty: {
      type: String,
      required: true,
      trim: true,
      maxlength: 50
    },
    location: {
      type: String,
      required: true,
      trim: true,
      maxlength: 100
    },
    availability: {
      type: [availabilitySlotSchema],
      default: []
    },
    contact: {
      phone: {
        type: String,
        required: true,
        trim: true,
        maxlength: 20
      },
      email: {
        type: String,
        required: true,
        trim: true,
        lowercase: true,
        match:
          /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/
      }
    },
    bio: {
      type: String,
      trim: true,
      maxlength: 1000
    },
    ratings: {
      type: Number,
      min: 0,
      max: 5,
      default: 0
    }
  },
  {
    timestamps: true
  }
);

const Dentist = mongoose.model('Dentist', dentistSchema);

export default Dentist;
