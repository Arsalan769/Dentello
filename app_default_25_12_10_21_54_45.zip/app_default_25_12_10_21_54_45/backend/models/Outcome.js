import mongoose from 'mongoose';

const outcomeSchema = new mongoose.Schema(
  {
    interview: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Interview',
      required: true,
      unique: true
    },
    notes: {
      type: String,
      trim: true,
      maxlength: 2000,
      default: ''
    },
    result: {
      type: String,
      enum: ['pass', 'fail', 'pending'],
      default: 'pending'
    }
  },
  {
    timestamps: true
  }
);

const Outcome = mongoose.model('Outcome', outcomeSchema);

export default Outcome;
