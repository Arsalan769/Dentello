import { body, param, validationResult } from 'express-validator';
import mongoose from 'mongoose';

export const interviewSchedulingRules = [
  body('dentistId')
    .notEmpty()
    .withMessage('dentistId is required')
    .custom((value) => {
      if (!mongoose.Types.ObjectId.isValid(value)) {
        throw new Error('Invalid dentistId');
      }
      return true;
    }),
  body('scheduledAt')
    .notEmpty()
    .withMessage('scheduledAt is required')
    .isISO8601()
    .withMessage('scheduledAt must be a valid ISO 8601 date'),
  body('type')
    .notEmpty()
    .withMessage('type is required')
    .isString()
    .trim()
    .isLength({ min: 1, max: 50 })
    .withMessage('type must be between 1 and 50 characters')
];

export const interviewOutcomeRules = [
  param('id')
    .notEmpty()
    .withMessage('Interview id is required')
    .custom((value) => {
      if (!mongoose.Types.ObjectId.isValid(value)) {
        throw new Error('Invalid interview id');
      }
      return true;
    }),
  body('notes')
    .optional()
    .isString()
    .trim()
    .isLength({ max: 2000 })
    .withMessage('Notes max length is 2000 characters'),
  body('result')
    .optional()
    .isIn(['pass', 'fail', 'pending'])
    .withMessage('Result must be pass, fail, or pending'),
  body('status')
    .optional()
    .isIn(['scheduled', 'completed', 'canceled'])
    .withMessage('Status must be scheduled, completed, or canceled')
];

export const validate = (req, res, next) => {
  const errors = validationResult(req);
  if (errors.isEmpty()) return next();

  return res.status(400).json({ errors: errors.array() });
};
