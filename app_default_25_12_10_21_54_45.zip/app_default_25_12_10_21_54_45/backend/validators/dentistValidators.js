import { query, param, validationResult } from 'express-validator';
import mongoose from 'mongoose';

export const dentistQueryValidationRules = [
  query('page')
    .optional()
    .isInt({ min: 1 })
    .withMessage('Page must be an integer greater than 0'),
  query('limit')
    .optional()
    .isInt({ min: 1, max: 100 })
    .withMessage('Limit must be an integer between 1 and 100'),
  query('specialty')
    .optional()
    .isString()
    .trim()
    .isLength({ max: 50 })
    .withMessage('Specialty must be max 50 characters'),
  query('location')
    .optional()
    .isString()
    .trim()
    .isLength({ max: 100 })
    .withMessage('Location must be max 100 characters'),
  query('availability')
    .optional()
    .isISO8601()
    .withMessage('Availability must be a valid ISO8601 date')
];

export const dentistIdValidationRules = [
  param('id').custom((value) => {
    if (!mongoose.Types.ObjectId.isValid(value)) {
      throw new Error('Invalid dentist ID');
    }
    return true;
  })
];

export const validate = (req, res, next) => {
  const errors = validationResult(req);
  if (errors.isEmpty()) return next();

  return res.status(400).json({ errors: errors.array() });
};
