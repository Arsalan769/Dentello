import Dentist from '../models/Dentist.js';

export const getDentists = async (req, res) => {
  try {
    const page = parseInt(req.query.page) > 0 ? parseInt(req.query.page) : 1;
    const limit = parseInt(req.query.limit) > 0 ? parseInt(req.query.limit) : 10;
    const { specialty, location, availability } = req.query;

    const filter = {};

    if (specialty) {
      filter.specialty = { $regex: new RegExp(`^${specialty}$`, 'i') };
    }
    if (location) {
      filter.location = { $regex: new RegExp(location, 'i') };
    }
    if (availability) {
      // availability expected as ISO date string, find dentists with availability on this date
      const date = new Date(availability);
      if (!isNaN(date.getTime())) {
        filter['availability.date'] = date;
      }
    }

    const total = await Dentist.countDocuments(filter);

    const dentists = await Dentist.find(filter)
      .skip((page - 1) * limit)
      .limit(limit)
      .sort({ createdAt: -1 });

    res.json({
      page,
      limit,
      total,
      totalPages: Math.ceil(total / limit),
      dentists
    });
  } catch (error) {
    console.error('Error fetching dentists:', error);
    res.status(500).json({ message: 'Server error' });
  }
};

export const getDentistById = async (req, res) => {
  try {
    const dentist = await Dentist.findById(req.params.id);
    if (!dentist) {
      return res.status(404).json({ message: 'Dentist not found' });
    }
    res.json(dentist);
  } catch (error) {
    console.error('Error fetching dentist by id:', error);
    res.status(500).json({ message: 'Server error' });
  }
};
