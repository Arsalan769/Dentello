import mongoose from 'mongoose';
import Dentist from '../models/Dentist.js';
import User from '../models/User.js';

const ShortlistSchema = new mongoose.Schema(
  {
    user: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      unique: true,
      required: true
    },
    dentists: [
      {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Dentist'
      }
    ]
  },
  {
    timestamps: true
  }
);

const Shortlist = mongoose.models.Shortlist || mongoose.model('Shortlist', ShortlistSchema);

export const getShortlist = async (req, res) => {
  try {
    let shortlist = await Shortlist.findOne({ user: req.user._id }).populate('dentists');
    if (!shortlist) {
      shortlist = await Shortlist.create({ user: req.user._id, dentists: [] });
    }
    res.json(shortlist.dentists);
  } catch (error) {
    console.error('Error fetching shortlist:', error);
    res.status(500).json({ message: 'Server error' });
  }
};

export const addToShortlist = async (req, res) => {
  const { dentistId } = req.body;
  try {
    if (!mongoose.Types.ObjectId.isValid(dentistId)) {
      return res.status(400).json({ message: 'Invalid dentistId' });
    }

    const dentist = await Dentist.findById(dentistId);
    if (!dentist) {
      return res.status(404).json({ message: 'Dentist not found' });
    }

    let shortlist = await Shortlist.findOne({ user: req.user._id });
    if (!shortlist) {
      shortlist = await Shortlist.create({ user: req.user._id, dentists: [] });
    }

    if (shortlist.dentists.includes(dentistId)) {
      return res.status(400).json({ message: 'Dentist already in shortlist' });
    }

    shortlist.dentists.push(dentistId);
    await shortlist.save();

    res.status(201).json({ message: 'Dentist added to shortlist' });
  } catch (error) {
    console.error('Error adding to shortlist:', error);
    res.status(500).json({ message: 'Server error' });
  }
};

export const removeFromShortlist = async (req, res) => {
  const { dentistId } = req.body;
  try {
    if (!mongoose.Types.ObjectId.isValid(dentistId)) {
      return res.status(400).json({ message: 'Invalid dentistId' });
    }

    const shortlist = await Shortlist.findOne({ user: req.user._id });
    if (!shortlist) {
      return res.status(404).json({ message: 'Shortlist not found' });
    }

    if (!shortlist.dentists.includes(dentistId)) {
      return res.status(400).json({ message: 'Dentist not in shortlist' });
    }

    shortlist.dentists = shortlist.dentists.filter(
      (dId) => dId.toString() !== dentistId.toString()
    );
    await shortlist.save();

    res.json({ message: 'Dentist removed from shortlist' });
  } catch (error) {
    console.error('Error removing from shortlist:', error);
    res.status(500).json({ message: 'Server error' });
  }
};
