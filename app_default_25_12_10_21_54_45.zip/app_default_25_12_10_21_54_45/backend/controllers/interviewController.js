import mongoose from 'mongoose';
import Interview from '../models/Interview.js';
import Outcome from '../models/Outcome.js';
import Dentist from '../models/Dentist.js';

export const scheduleInterview = async (req, res) => {
  try {
    const { dentistId, scheduledAt, type } = req.body;

    if (!mongoose.Types.ObjectId.isValid(dentistId)) {
      return res.status(400).json({ message: 'Invalid dentistId' });
    }

    const dentist = await Dentist.findById(dentistId);
    if (!dentist) {
      return res.status(404).json({ message: 'Dentist not found' });
    }

    const scheduledDate = new Date(scheduledAt);
    if (isNaN(scheduledDate.getTime())) {
      return res.status(400).json({ message: 'Invalid scheduledAt date' });
    }

    // Optional: check availability of dentist at this time (not implemented here)

    const interview = new Interview({
      user: req.user._id,
      dentist: dentistId,
      scheduledAt: scheduledDate,
      type,
      status: 'scheduled'
    });

    await interview.save();

    res.status(201).json(interview);
  } catch (error) {
    console.error('Error scheduling interview:', error);
    res.status(500).json({ message: 'Server error' });
  }
};

export const getUserInterviews = async (req, res) => {
  try {
    const interviews = await Interview.find({ user: req.user._id })
      .populate('dentist')
      .populate('outcome')
      .sort({ scheduledAt: -1 });

    res.json(interviews);
  } catch (error) {
    console.error('Error fetching user interviews:', error);
    res.status(500).json({ message: 'Server error' });
  }
};

export const updateInterviewOutcome = async (req, res) => {
  try {
    const interviewId = req.params.id;
    const { notes, result, status } = req.body;

    if (!mongoose.Types.ObjectId.isValid(interviewId)) {
      return res.status(400).json({ message: 'Invalid interview id' });
    }

    const interview = await Interview.findById(interviewId);
    if (!interview) {
      return res.status(404).json({ message: 'Interview not found' });
    }

    // Only user who owns interview or admin can update - for simplicity, user only
    if (interview.user.toString() !== req.user._id.toString()) {
      return res.status(403).json({ message: 'Forbidden' });
    }

    let outcome = await Outcome.findOne({ interview: interview._id });
    if (!outcome) {
      outcome = new Outcome({
        interview: interview._id,
        notes: notes || '',
        result: result || 'pending'
      });
    } else {
      if (notes !== undefined) outcome.notes = notes;
      if (result !== undefined) outcome.result = result;
    }
    await outcome.save();

    // Update interview reference to outcome if not set
    if (!interview.outcome) {
      interview.outcome = outcome._id;
    }

    // Optionally update interview status if provided
    if (status && ['scheduled', 'completed', 'canceled'].includes(status)) {
      interview.status = status;
    }

    await interview.save();

    // Populate outcome in interview for response
    const updatedInterview = await Interview.findById(interview._id)
      .populate('dentist')
      .populate('outcome');

    res.json(updatedInterview);
  } catch (error) {
    console.error('Error updating interview outcome:', error);
    res.status(500).json({ message: 'Server error' });
  }
};
