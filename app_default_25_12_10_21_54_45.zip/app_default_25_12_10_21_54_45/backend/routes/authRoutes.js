import express from 'express';
import { login } from '../controllers/authController.js';
import { loginValidationRules, validate } from '../validators/authValidators.js';

const router = express.Router();

router.post('/login', loginValidationRules, validate, login);

export default router;
