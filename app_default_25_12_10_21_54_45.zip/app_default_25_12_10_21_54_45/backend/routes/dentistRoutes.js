import express from 'express';
import { protect } from '../middleware/authMiddleware.js';
import {
  getDentists,
  getDentistById
} from '../controllers/dentistController.js';
import {
  dentistQueryValidationRules,
  dentistIdValidationRules,
  validate
} from '../validators/dentistValidators.js';

const router = express.Router();

router.get('/', protect, dentistQueryValidationRules, validate, getDentists);
router.get('/:id', protect, dentistIdValidationRules, validate, getDentistById);

export default router;
