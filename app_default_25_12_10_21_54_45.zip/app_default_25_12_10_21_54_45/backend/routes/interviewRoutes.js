import express from 'express';
import { protect } from '../middleware/authMiddleware.js';
import {
  scheduleInterview,
  getUserInterviews,
  updateInterviewOutcome
} from '../controllers/interviewController.js';
import {
  interviewSchedulingRules,
  interviewOutcomeRules,
  validate
} from '../validators/interviewValidators.js';

const router = express.Router();

router.use(protect);

router.post('/', interviewSchedulingRules, validate, scheduleInterview);
router.get('/', getUserInterviews);
router.patch('/:id/outcome', interviewOutcomeRules, validate, updateInterviewOutcome);

export default router;
