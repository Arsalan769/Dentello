import express from 'express';
import { protect } from '../middleware/authMiddleware.js';
import {
  getShortlist,
  addToShortlist,
  removeFromShortlist
} from '../controllers/shortlistController.js';
import { check, validationResult } from 'express-validator';

const router = express.Router();

router.use(protect);

router.get('/', getShortlist);

router.post(
  '/',
  [check('dentistId').isMongoId().withMessage('Valid dentistId is required')],
  (req, res, next) => {
    const errors = validationResult(req);
    if (!errors.isEmpty())
      return res.status(400).json({ errors: errors.array() });
    next();
  },
  addToShortlist
);

router.delete(
  '/',
  [check('dentistId').isMongoId().withMessage('Valid dentistId is required')],
  (req, res, next) => {
    const errors = validationResult(req);
    if (!errors.isEmpty())
      return res.status(400).json({ errors: errors.array() });
    next();
  },
  removeFromShortlist
);

export default router;
