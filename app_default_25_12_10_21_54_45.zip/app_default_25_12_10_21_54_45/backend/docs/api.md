# Dentello API Documentation

## Authentication

### POST `/api/auth/login`

Authenticate user and receive JWT token.

**Request Body:**

- `username` (string, required): User's username
- `password` (string, required): User's password

**Response:**

- `200 OK`
  