import request from 'supertest';
import mongoose from 'mongoose';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import User from '../models/User.js';
import app from '../server.js';

let server;
let testUser;

beforeAll(async () => {
  process.env.JWT_SECRET = 'testsecret';
  server = app.listen(6000);

  await mongoose.connect('mongodb://localhost:27017/dentello_test_auth', {
    useNewUrlParser: true,
    useUnifiedTopology: true
  });

  const hashedPassword = await bcrypt.hash('Password123', 10);
  testUser = await User.create({
    username: 'testuser',
    email: 'testuser@example.com',
    password: hashedPassword,
    role: 'user'
  });
});

afterAll(async () => {
  await User.deleteMany({});
  await mongoose.connection.close();
  server.close();
});

describe('POST /api/auth/login', () => {
  it('should login successfully with correct credentials', async () => {
    const res = await request(server)
      .post('/api/auth/login')
      .send({
        username: 'testuser',
        password: 'Password123'
      });

    expect(res.statusCode).toBe(200);
    expect(res.body.token).toBeDefined();
    expect(res.body.user.username).toBe('testuser');
  });

  it('should reject login with wrong password', async () => {
    const res = await request(server)
      .post('/api/auth/login')
      .send({
        username: 'testuser',
        password: 'WrongPassword'
      });

    expect(res.statusCode).toBe(401);
    expect(res.body.message).toBe('Invalid credentials');
  });

  it('should reject login with non-existent username', async () => {
    const res = await request(server)
      .post('/api/auth/login')
      .send({
        username: 'nonexistent',
        password: 'Password123'
      });

    expect(res.statusCode).toBe(401);
    expect(res.body.message).toBe('Invalid credentials');
  });

  it('should reject login with missing fields', async () => {
    const res = await request(server).post('/api/auth/login').send({});

    expect(res.statusCode).toBe(400);
    expect(res.body.errors).toBeDefined();
  });
});
