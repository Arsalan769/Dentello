import request from 'supertest';
import mongoose from 'mongoose';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import app from '../server.js';
import User from '../models/User.js';
import Dentist from '../models/Dentist.js';
import Interview from '../models/Interview.js';
import Outcome from '../models/Outcome.js';

let server;
let userToken;
let userId;
let dentistId;
let interviewId;

beforeAll(async () => {
  process.env.JWT_SECRET = 'testsecret';
  server = app.listen(6003);

  await mongoose.connect('mongodb://localhost:27017/dentello_test_interview', {
    useNewUrlParser: true,
    useUnifiedTopology: true
  });

  const hashedPassword = await bcrypt.hash('Password123', 10);
  const user = await User.create({
    username: 'interviewuser',
    email: 'interviewuser@example.com',
    password: hashedPassword,
    role: 'user'
  });
  userId = user._id;

  userToken = jwt.sign({ id: user._id, username: user.username, role: user.role }, process.env.JWT_SECRET, {
    expiresIn: '7d'
  });

  const dentist = await Dentist.create({
    name: 'Dr. Interview',
    specialty: 'General',
    location: 'Chicago',
    availability: [],
    contact: { phone: '555-555-5555', email: 'interview@example.com' },
    bio: 'General dentist.',
    ratings: 4.2
  });
  dentistId = dentist._id;
});

afterAll(async () => {
  await User.deleteMany({});
  await Dentist.deleteMany({});
  await Interview.deleteMany({});
  await Outcome.deleteMany({});
  await mongoose.connection.close();
  server.close();
});

describe('POST /api/interviews', () => {
  it('should schedule an interview', async () => {
    const res = await request(server)
      .post('/api/interviews')
      .set('Authorization', `Bearer ${userToken}`)
      .send({
        dentistId: dentistId.toString(),
        scheduledAt: new Date(Date.now() + 86400000).toISOString(),
        type: 'Zoom'
      });

    expect(res.statusCode).toBe(201);
    expect(res.body.dentist).toBe(dentistId.toString());
    interviewId = res.body._id;
  });

  it('should reject scheduling with invalid dentistId', async () => {
    const res = await request(server)
      .post('/api/interviews')
      .set('Authorization', `Bearer ${userToken}`)
      .send({
        dentistId: 'invalidid',
        scheduledAt: new Date(Date.now() + 86400000).toISOString(),
        type: 'Zoom'
      });

    expect(res.statusCode).toBe(400);
  });

  it('should reject scheduling with missing fields', async () => {
    const res = await request(server)
      .post('/api/interviews')
      .set('Authorization', `Bearer ${userToken}`)
      .send({});

    expect(res.statusCode).toBe(400);
  });
});

describe('GET /api/interviews', () => {
  it('should get user interviews', async () => {
    const res = await request(server)
      .get('/api/interviews')
      .set('Authorization', `Bearer ${userToken}`);

    expect(res.statusCode).toBe(200);
    expect(Array.isArray(res.body)).toBe(true);
    expect(res.body.length).toBeGreaterThan(0);
  });
});

describe('PATCH /api/interviews/:id/outcome', () => {
  it('should update interview outcome', async () => {
    const res = await request(server)
      .patch(`/api/interviews/${interviewId}/outcome`)
      .set('Authorization', `Bearer ${userToken}`)
      .send({
        notes: 'Candidate did well',
        result: 'pass',
        status: 'completed'
      });

    expect(res.statusCode).toBe(200);
    expect(res.body.outcome).toBeDefined();
    expect(res.body.status).toBe('completed');
  });

  it('should reject update with invalid interview id', async () => {
    const res = await request(server)
      .patch('/api/interviews/invalidid/outcome')
      .set('Authorization', `Bearer ${userToken}`)
      .send({
        notes: 'Test notes',
        result: 'pass',
        status: 'completed'
      });

    expect(res.statusCode).toBe(400);
  });

  it('should reject update by unauthorized user', async () => {
    const otherUser = await User.create({
      username: 'otheruser',
      email: 'otheruser@example.com',
      password: await bcrypt.hash('Password123', 10),
      role: 'user'
    });
    const otherToken = jwt.sign({ id: otherUser._id, username: otherUser.username, role: otherUser.role }, process.env.JWT_SECRET, {
      expiresIn: '7d'
    });

    const res = await request(server)
      .patch(`/api/interviews/${interviewId}/outcome`)
      .set('Authorization', `Bearer ${otherToken}`)
      .send({
        notes: 'Unauthorized update attempt',
        result: 'fail',
        status: 'completed'
      });

    expect(res.statusCode).toBe(403);
  });
});
