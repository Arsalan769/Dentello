import request from 'supertest';
import mongoose from 'mongoose';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import app from '../server.js';
import User from '../models/User.js';
import Dentist from '../models/Dentist.js';

let server;
let token;
let userId;
let dentistId;

beforeAll(async () => {
  process.env.JWT_SECRET = 'testsecret';
  server = app.listen(6002);

  await mongoose.connect('mongodb://localhost:27017/dentello_test_shortlist', {
    useNewUrlParser: true,
    useUnifiedTopology: true
  });

  const hashedPassword = await bcrypt.hash('Password123', 10);
  const user = await User.create({
    username: 'shortlistuser',
    email: 'shortlistuser@example.com',
    password: hashedPassword,
    role: 'user'
  });
  userId = user._id;

  token = jwt.sign({ id: user._id, username: user.username, role: user.role }, process.env.JWT_SECRET, {
    expiresIn: '7d'
  });

  const dentist = await Dentist.create({
    name: 'Dr. Jane Doe',
    specialty: 'Pediatrics',
    location: 'San Francisco',
    availability: [],
    contact: { phone: '987-654-3210', email: 'janedoe@example.com' },
    bio: 'Pediatric dentist with 15 years experience.',
    ratings: 4.9
  });
  dentistId = dentist._id;
});

afterAll(async () => {
  await User.deleteMany({});
  await Dentist.deleteMany({});
  await mongoose.connection.close();
  server.close();
});

describe('Shortlist API', () => {
  it('should return empty shortlist initially', async () => {
    const res = await request(server).get('/api/shortlist').set('Authorization', `Bearer ${token}`);

    expect(res.statusCode).toBe(200);
    expect(Array.isArray(res.body)).toBe(true);
    expect(res.body.length).toBe(0);
  });

  it('should add dentist to shortlist', async () => {
    const res = await request(server)
      .post('/api/shortlist')
      .set('Authorization', `Bearer ${token}`)
      .send({ dentistId: dentistId.toString() });

    expect(res.statusCode).toBe(201);
    expect(res.body.message).toBe('Dentist added to shortlist');
  });

  it('should not add the same dentist twice', async () => {
    const res = await request(server)
      .post('/api/shortlist')
      .set('Authorization', `Bearer ${token}`)
      .send({ dentistId: dentistId.toString() });

    expect(res.statusCode).toBe(400);
  });

  it('should get shortlist with one dentist', async () => {
    const res = await request(server).get('/api/shortlist').set('Authorization', `Bearer ${token}`);

    expect(res.statusCode).toBe(200);
    expect(res.body.length).toBe(1);
    expect(res.body[0]._id.toString()).toBe(dentistId.toString());
  });

  it('should remove dentist from shortlist', async () => {
    const res = await request(server)
      .delete('/api/shortlist')
      .set('Authorization', `Bearer ${token}`)
      .send({ dentistId: dentistId.toString() });

    expect(res.statusCode).toBe(200);
    expect(res.body.message).toBe('Dentist removed from shortlist');
  });

  it('should have empty shortlist after removal', async () => {
    const res = await request(server).get('/api/shortlist').set('Authorization', `Bearer ${token}`);

    expect(res.statusCode).toBe(200);
    expect(res.body.length).toBe(0);
  });
});
