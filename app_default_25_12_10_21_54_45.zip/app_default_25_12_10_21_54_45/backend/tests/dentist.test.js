import request from 'supertest';
import mongoose from 'mongoose';
import app from '../server.js';
import Dentist from '../models/Dentist.js';
import User from '../models/User.js';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';

let server;
let token;
let testDentist;

beforeAll(async () => {
  process.env.JWT_SECRET = 'testsecret';
  server = app.listen(6001);

  await mongoose.connect('mongodb://localhost:27017/dentello_test_dentist', {
    useNewUrlParser: true,
    useUnifiedTopology: true
  });

  const hashedPassword = await bcrypt.hash('Password123', 10);
  const user = await User.create({
    username: 'dentistuser',
    email: 'dentistuser@example.com',
    password: hashedPassword,
    role: 'user'
  });

  token = jwt.sign({ id: user._id, username: user.username, role: user.role }, process.env.JWT_SECRET, {
    expiresIn: '7d'
  });

  testDentist = await Dentist.create({
    name: 'Dr. John Smith',
    specialty: 'Orthodontics',
    location: 'New York',
    availability: [
      { date: new Date('2024-07-01T00:00:00.000Z'), startTime: '09:00', endTime: '17:00' }
    ],
    contact: { phone: '123-456-7890', email: 'johnsmith@example.com' },
    bio: 'Experienced orthodontist with 10 years of practice.',
    ratings: 4.5
  });
});

afterAll(async () => {
  await Dentist.deleteMany({});
  await User.deleteMany({});
  await mongoose.connection.close();
  server.close();
});

describe('GET /api/dentists', () => {
  it('should return list of dentists with valid token', async () => {
    const res = await request(server)
      .get('/api/dentists')
      .set('Authorization', `Bearer ${token}`);

    expect(res.statusCode).toBe(200);
    expect(Array.isArray(res.body.dentists)).toBe(true);
    expect(res.body.dentists.length).toBeGreaterThan(0);
  });

  it('should filter dentists by specialty', async () => {
    const res = await request(server)
      .get('/api/dentists')
      .query({ specialty: 'Orthodontics' })
      .set('Authorization', `Bearer ${token}`);

    expect(res.statusCode).toBe(200);
    expect(res.body.dentists[0].specialty).toMatch(/orthodontics/i);
  });

  it('should return 401 without token', async () => {
    const res = await request(server).get('/api/dentists');

    expect(res.statusCode).toBe(401);
  });
});

describe('GET /api/dentists/:id', () => {
  it('should return dentist details with valid id and token', async () => {
    const res = await request(server)
      .get(`/api/dentists/${testDentist._id}`)
      .set('Authorization', `Bearer ${token}`);

    expect(res.statusCode).toBe(200);
    expect(res.body.name).toBe('Dr. John Smith');
  });

  it('should return 404 for non-existing id', async () => {
    const nonExistingId = new mongoose.Types.ObjectId();
    const res = await request(server)
      .get(`/api/dentists/${nonExistingId}`)
      .set('Authorization', `Bearer ${token}`);

    expect(res.statusCode).toBe(404);
  });

  it('should return 400 for invalid id', async () => {
    const res = await request(server)
      .get('/api/dentists/invalidid123')
      .set('Authorization', `Bearer ${token}`);

    expect(res.statusCode).toBe(400);
  });
});
